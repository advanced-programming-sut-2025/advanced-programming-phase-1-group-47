package models;

public class eatble {
    private int energyChanger;
}
