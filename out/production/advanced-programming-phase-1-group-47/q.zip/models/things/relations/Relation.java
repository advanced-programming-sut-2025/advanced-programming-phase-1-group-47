package models.things.relations;


public abstract class Relation{
    
}
