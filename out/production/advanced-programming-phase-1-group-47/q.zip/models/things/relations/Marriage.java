package models.things.relations;

public class Marriage {
}
