package models.things.products;

public abstract class Crop extends Product {
    // Constructor for Crop
    public Crop(String name, int itemID, int value, int parentItemID, int amount, boolean isEdible, int energy, int health) {
        super(name, itemID, value, parentItemID, amount, isEdible, energy, health);
    }
}
