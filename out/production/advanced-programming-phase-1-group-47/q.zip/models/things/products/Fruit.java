package models.things.products;

import models.enums.Season;

public abstract class Fruit extends Product {
    private final Season fruitSeason;

    public Fruit(String name, int itemID, int value, int parentItemID, int amount,
                 boolean isEdible, int energy, int health, Season fruitSeason) {
        super(name, itemID, value, parentItemID, amount, isEdible, energy, health);
        this.fruitSeason = fruitSeason;
    }

    public Season getFruitSeason() {
        return fruitSeason;
    }
}
