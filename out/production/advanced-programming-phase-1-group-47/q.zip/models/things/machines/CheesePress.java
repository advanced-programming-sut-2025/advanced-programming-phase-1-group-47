package models.things.machines;

public class CheesePress extends Machine {
    public CheesePress(String name, int itemID, int value, int parentItemID, int amount) {
        super(name, itemID, value, parentItemID, amount);
    }
}
