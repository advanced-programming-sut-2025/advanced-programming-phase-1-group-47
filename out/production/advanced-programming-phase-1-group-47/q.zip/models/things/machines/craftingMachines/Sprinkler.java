package models.things.machines.craftingMachines;

import models.things.machines.Machine;

public class Sprinkler extends Machine {
    public Sprinkler(String name, int itemID, int value, int parentItemID, int amount) {
        super(name, itemID, value, parentItemID, amount);
    }
}
