package models.things.machines.craftingMachines;

import models.things.machines.Machine;

public class Bomber extends Machine {
    public Bomber(String name, int itemID, int value, int parentItemID, int amount) {
        super(name, itemID, value, parentItemID, amount);
    }
}
