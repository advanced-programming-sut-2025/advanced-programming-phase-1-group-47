package models.things.machines;

public class Keg extends Machine {
    public Keg(String name, int itemID, int value, int parentItemID, int amount) {
        super(name, itemID, value, parentItemID, amount);
    }
}
