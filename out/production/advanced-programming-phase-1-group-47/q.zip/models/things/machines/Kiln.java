package models.things.machines;

public class Kiln extends Machine {
    public Kiln(String name, int itemID, int value, int parentItemID, int amount) {
        super(name, itemID, value, parentItemID, amount);
    }
}
