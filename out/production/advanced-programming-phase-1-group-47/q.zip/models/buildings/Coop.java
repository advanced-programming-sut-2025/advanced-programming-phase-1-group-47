package models.buildings;

import java.util.ArrayList;
import models.*;
public class Coop extends Building {
    ArrayList<Animal> animals;
    public Coop(Ground ground) {

        super(ground);
    }
}
