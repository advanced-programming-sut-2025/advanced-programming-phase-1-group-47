package models.buildings;


import models.Ground;
import models.Map;

public  class NpcHouse extends Building  {
    public NpcHouse(Ground ground) {
        super(ground);
    }
}
