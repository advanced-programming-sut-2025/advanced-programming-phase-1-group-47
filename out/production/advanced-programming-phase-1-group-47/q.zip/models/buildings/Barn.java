package models.buildings;

import java.util.ArrayList;

import models.Animal;

public class Barn {
    ArrayList<Animal> animals;
}
