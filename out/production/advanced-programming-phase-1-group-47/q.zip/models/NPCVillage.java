package models;

public class NPCVillage{
}
