package models;

public class GameFinal {
    public Game game;
    public Map map;
    public GameFinal(Game game, Map map) {
        this.game = game;
        this.map = map;
    }
}
