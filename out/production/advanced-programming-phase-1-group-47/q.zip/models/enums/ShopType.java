package models.enums;

public enum ShopType {
    BlackSmith,
    JojaMart,
    Pierres,
    Carpenters,
    FishShop,
    Marnies,
    TheSaloon;
}
