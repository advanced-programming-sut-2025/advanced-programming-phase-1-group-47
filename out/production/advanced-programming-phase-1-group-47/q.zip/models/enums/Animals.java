package models.enums;

public enum Animals {
    CHICKEN,
    COW,
    DUCK,
    BUNNY,
    DINOSAUR,
    GOAT,
    SHEEP,
    PIG;
}
