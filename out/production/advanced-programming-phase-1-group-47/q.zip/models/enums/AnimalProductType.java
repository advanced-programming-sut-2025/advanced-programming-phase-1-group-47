package models.enums;

import models.things.products.Product;

public class AnimalProductType {
    ;
    Product product;
    public AnimalProductType(Product product) {
        this.product = product;
    }
}
