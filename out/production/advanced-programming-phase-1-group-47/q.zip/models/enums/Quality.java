package models.enums;

public enum Quality {
    Regular,
    Copper,
    SILVER,
    GOLD,
    IRIDIUM;
}
