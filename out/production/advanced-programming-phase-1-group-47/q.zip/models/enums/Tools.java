package models.enums;

public enum Tools {
    HOE,
    PICKAXE,
    AXE,
    WATERING_CAN,
    FISHING_POLE,
    Scythe,
    Milk_pail,
    Shear;
}
