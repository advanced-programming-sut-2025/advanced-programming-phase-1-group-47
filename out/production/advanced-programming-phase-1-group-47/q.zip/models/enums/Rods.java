package models.enums;

public enum Rods {
    TRAINING_ROD,
    BAMBOO_POLE,
    FIBERGLASS_ROD,
    IRIDIUM_ROD;
}
