package models.enums;

import models.Fish;

public enum FishType {
    ;
    final AnimalProductType productType;
    FishType(AnimalProductType productType) {
        this.productType = productType;
    }
}
