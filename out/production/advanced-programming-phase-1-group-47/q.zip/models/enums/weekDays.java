package models.enums;

public enum weekDays {
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Sunday,
    Saturday
    ;
}
