package models;
import models.Point;
import models.enums.SeedType;

public class Seed {
    int id;
    Point point;
    Tree tree;
    SeedType seedType;

}
