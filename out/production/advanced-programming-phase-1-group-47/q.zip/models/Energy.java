package models;

public class Energy {
    private int energyCap;
    private int currentEnergy;

    public int getEnergyCap() {
        return energyCap;
    }

    public void setEnergyCap(int energyCap) {
        this.energyCap = energyCap;
    }

    public int getCurrentEnergy() {
        return currentEnergy;
    }

    public void setCurrentEnergy(int currentEnergy) {
        this.currentEnergy = currentEnergy;
    }
}
