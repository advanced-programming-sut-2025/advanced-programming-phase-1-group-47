package views.menu;

import java.util.Scanner;

public class TradeMenu extends AppMenu {
    @Override
    public void check(Scanner scanner) {
        super.check(scanner);
    }
}
