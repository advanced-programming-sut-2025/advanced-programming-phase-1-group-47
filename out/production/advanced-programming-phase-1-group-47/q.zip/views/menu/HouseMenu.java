package views.menu;

import java.util.Scanner;

public class HouseMenu extends AppMenu {
    @Override
    public void check(Scanner scanner) {
        super.check(scanner);
    }
}
