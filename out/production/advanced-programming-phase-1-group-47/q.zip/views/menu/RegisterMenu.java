package views.menu;

import java.util.Scanner;

public class RegisterMenu extends AppMenu {
    @Override
    public void check(Scanner scanner) {
        super.check(scanner);
    }
    
}