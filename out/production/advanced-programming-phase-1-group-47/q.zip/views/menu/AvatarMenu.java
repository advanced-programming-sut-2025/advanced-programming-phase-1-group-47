package views.menu;

// import AppMenu;

import java.util.Scanner;

public class AvatarMenu extends AppMenu {
    @Override
    public void check(Scanner scanner) {
        super.check(scanner);
    }
}
