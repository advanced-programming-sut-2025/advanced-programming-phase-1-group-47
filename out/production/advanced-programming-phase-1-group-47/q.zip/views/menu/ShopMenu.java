package views.menu;

import java.util.Scanner;
import models.enums.ShopType;

public class ShopMenu extends AppMenu{
    private ShopType type;
    public void check(Scanner scanner) {
        super.check(scanner);
    }
}
