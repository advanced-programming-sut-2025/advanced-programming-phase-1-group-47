package views.menu;

import java.util.Scanner;

public abstract class AppMenu {
    public void check(Scanner scanner) {

    }
}
