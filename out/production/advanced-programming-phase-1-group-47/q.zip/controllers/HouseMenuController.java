package controllers;

import models.*;
import models.things.products.Recipe;
public class HouseMenuController {
    public Result CookFood(Recipe recipe) {
        return null;
    }
}
