package controllers;

import models.Result;

public class AvatarMenuController {
    public Result<String> exit() {
        return null;
    }
    public Result<String> changeMenu() {
        return null;
    }
    public Result<String> showMenu() {
        return null;
    }
}