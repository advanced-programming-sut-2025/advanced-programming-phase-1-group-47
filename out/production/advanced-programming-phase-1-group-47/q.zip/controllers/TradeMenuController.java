package controllers;

import models.Player;
import models.Result;
import models.things.Item;

public class TradeMenuController {
    public Result<String> trade(Player giverPlayer ,Player TakerPlayer , int giverMoney , Item giverItem , int takerMoney , Item takerItem){
        return null;
    }
    public Result<String> AcceptOrDenyTrade(String messege) {
        return null;
    }
}
