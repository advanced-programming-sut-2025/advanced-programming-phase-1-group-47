package controllers;
import  models.Result;
public class RegisterMenuController {
    public Result<String> exit() {
        return null;
    }
    public Result<String> changeMenu() {
        return null;
    }
    public Result<String> showMenu() {
        return null;
    }
    public Result<String> register(String username, String password, String email, String nickname, String gender) {
        return null;
    }
    public String randomPassword() {
        return null;
    }
}   